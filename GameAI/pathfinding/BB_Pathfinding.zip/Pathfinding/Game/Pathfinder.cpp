#include "Pathfinder.h"
#include "Graph.h"
#include "Path.h"

Pathfinder::Pathfinder( Graph* pGraph )
:mpGraph(pGraph)
{
}

Pathfinder::~Pathfinder()
{
}

